import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.commons.metaclass.*
import org.codehaus.groovy.grails.commons.*
import org.apache.log4j.Logger

import org.springframework.transaction.interceptor.TransactionProxyFactoryBean
import org.codehaus.groovy.grails.orm.support.GroovyAwareNamedTransactionAttributeSource

class I18nFieldsGrailsPlugin {
    static final def log = Logger.getLogger(I18nFieldsGrailsPlugin)

    // the plugin version
    def version = "0.5.2"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/conf/Config.groovy",
            "grails-app/views/error.gsp",
            "grails-app/services/i18nfields/I18nTestService.groovy",
            "grails-app/domain/i18nfields/tests/TestDomain.groovy",
            "grails-app/domain/i18nfields/tests/TestDomainTwo.groovy",
            "grails-app/domain/i18nfields/tests/NewFieldTests.groovy"
    ]

    def config = ConfigurationHolder.config

    // TODO Fill in these fields
    def author = "Jorge Uriarte"
    def authorEmail = "jorge.uriarte@omelas.net"
    def title = "i18n Fields"
    def description = '''\\
This plugin provide an easy way of declarativily localize database fields of your content tables.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/i18n-fields"

    def withLocale = { newLocale, Closure clos ->
        def previous = i18nfields.I18nFieldsHelper.getLocale()
        i18nfields.I18nFieldsHelper.setLocale(newLocale)
        clos.run()
        i18nfields.I18nFieldsHelper.setLocale(previous)
    }


    def doWithDynamicMethods = { ctx ->
        MetaClassRegistry registry = GroovySystem.metaClassRegistry
        println "Adding 'withLocale' to controllers, services, taglibs, codecs and bootstrap..."
        ['controller', 'service', 'tagLib', 'codec', 'bootstrap'].each {
            application."${it}Classes".each { theClass ->
                theClass.metaClass.withLocale = withLocale
            }
        }
    }

}

