package i18nfields

class Literal implements Serializable {

    String className
    String objectId
    String locale
    String name
    String text

    static constraints = {
        className(maxSize:100)
        objectId(maxSize:16)
        locale(size:5..6)
        name(maxSize:30)
        text(maxSize:4000)
    }

    static mapping = {
        id composite:['className', 'objectId', 'locale', 'name']
    }
}

