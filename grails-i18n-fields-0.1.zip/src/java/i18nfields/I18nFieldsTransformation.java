package i18nfields;

import java.lang.reflect.Modifier;
import java.util.Iterator;
import java.util.List;

import org.codehaus.groovy.ast.ASTNode;
import org.codehaus.groovy.ast.ClassNode;
import org.codehaus.groovy.ast.FieldNode;
import org.codehaus.groovy.ast.expr.ClosureExpression;
import org.codehaus.groovy.ast.expr.ConstantExpression;
import org.codehaus.groovy.ast.expr.Expression;
import org.codehaus.groovy.ast.expr.ListExpression;
import org.codehaus.groovy.ast.expr.MapEntryExpression;
import org.codehaus.groovy.ast.expr.MethodCallExpression;
import org.codehaus.groovy.ast.expr.NamedArgumentListExpression;
import org.codehaus.groovy.ast.expr.VariableExpression;
import org.codehaus.groovy.ast.stmt.BlockStatement;
import org.codehaus.groovy.ast.stmt.ExpressionStatement;
import org.codehaus.groovy.ast.stmt.Statement;
import org.codehaus.groovy.control.CompilePhase;
import org.codehaus.groovy.control.SourceUnit;
import org.codehaus.groovy.transform.ASTTransformation;
import org.codehaus.groovy.transform.GroovyASTTransformation;

/**
  * TODO: New fields might be nullable if the language-aware getter will fallback to the default
  * if no content is provided.
  * TODO: Default lang field *must* have a value... do we need the field or will we assume that th
  * original field ("name") is the backend for the default language?
  * TODO: Should the default lang be specified and thus no field created for it?
  * TODO: If the getter to be generated already exists (some process wrapping the field), we will WARN
  * and leave it unchanged. It's then programmer's responsability to provide access to i18n fields
  * TODO: Provide a wrapper to LCH so it's easy to program ad-hoc i18n inside the classes (protected method?)
  * TODO: Provide a setter for language (LCH??) so we can inject a custom i18n to an object if needed
  */
@GroovyASTTransformation(phase = CompilePhase.CANONICALIZATION)
public class I18nFieldsTransformation implements ASTTransformation {

	public void visit(ASTNode[] astNodes, SourceUnit sourceUnit) {

		for (ASTNode astNode : astNodes) {
			if (astNode instanceof ClassNode) {
				ClassNode classNode = (ClassNode) astNode;
				ListExpression fields = (ListExpression)classNode.getField("i18n_fields").getInitialValueExpression();
				ListExpression langs = (ListExpression)classNode.getField("i18n_langs").getInitialValueExpression();
				if (fields != null && langs != null) {
				    System.out.println("Adding i18n fields to " + classNode.getName());
				    for (Iterator<Expression> itt = fields.getExpressions().iterator(); itt.hasNext(); ) {
				    	String field = (String)((ConstantExpression)itt.next()).getValue();
				    	if (classNode.getField(field) == null) {
				    		System.out.println("* ERROR: There's no such field '" + field + "' as stated in i18n_fields declaration.");
				    	} else {
					    	System.out.println("* Field: " + field);
					    	boolean nullable = hasNullableConstraint(classNode, field);
					    	System.out.println("    nullable: " + nullable);
				            for (Iterator<Expression> it = langs.getExpressions().iterator(); it.hasNext();) {
					            String lang = (String)((ConstantExpression)it.next()).getValue();
					            System.out.println("  - " + lang);
						    	classNode.addProperty(field + "_" + lang, Modifier.PUBLIC, new ClassNode(String.class), new ConstantExpression(lang), null, null);
						    	addNullableConstraint(classNode, field + "_" + lang);
				            }
				            if (nullable) {
				            	
				            }
				    	}
				    }
				}
			}
		}
	}

	public void addNullableConstraint(ClassNode classNode,String fieldName){
		FieldNode closure = classNode.getDeclaredField("constraints");
		if(closure!=null && !hasNullableConstraint(classNode, fieldName)){
			ClosureExpression exp = (ClosureExpression)closure.getInitialExpression();
			BlockStatement block = (BlockStatement) exp.getCode();

			NamedArgumentListExpression namedarg = new NamedArgumentListExpression();
			namedarg.addMapEntryExpression(new ConstantExpression("nullable"), new ConstantExpression(true));
			MethodCallExpression constExpr = new MethodCallExpression(
				VariableExpression.THIS_EXPRESSION,
				new ConstantExpression(fieldName),
				namedarg
				);
			block.addStatement(new ExpressionStatement(constExpr));
			System.out.println("Added " +fieldName + " 'nullable: true' constraint.");
		}
	}
	
	public boolean hasNullableConstraint(ClassNode classNode, String fieldName) {
		FieldNode closure = classNode.getField("constraints");
		if (closure != null) {
			ClosureExpression exp = (ClosureExpression)closure.getInitialExpression();
			BlockStatement block = (BlockStatement)exp.getCode();
			List<Statement> ments = block.getStatements();
			for(Statement expstat : ments){
				if(expstat instanceof ExpressionStatement && ((ExpressionStatement)expstat).getExpression() instanceof MethodCallExpression){
					MethodCallExpression methexp = (MethodCallExpression)((ExpressionStatement)expstat).getExpression();
					if (methexp.getMethodAsString().equals(fieldName)) {
						NamedArgumentListExpression args = (NamedArgumentListExpression)methexp.getArguments();
						for (Iterator<MapEntryExpression> it = args.getMapEntryExpressions().iterator(); it.hasNext(); ) {
							MapEntryExpression mee = it.next();
							String nullable = (String)((ConstantExpression)mee.getKeyExpression()).getValue();
							return nullable.equals("nullable");
						}
					}
				}
			}
		}
		return false;
	}

	public void cloneNullableConstraint(ClassNode classNode, String fieldName) {
		FieldNode closure = classNode.getDeclaredField("constraints");
		if (closure != null) {
			ClosureExpression exp = (ClosureExpression)closure.getInitialExpression();
			BlockStatement block = (BlockStatement)exp.getCode();
			List<Statement> ments = block.getStatements();
			for(Statement expstat : ments){
				if(expstat instanceof ExpressionStatement && ((ExpressionStatement)expstat).getExpression() instanceof MethodCallExpression){
					MethodCallExpression methexp = (MethodCallExpression)((ExpressionStatement)expstat).getExpression();
					NamedArgumentListExpression args = (NamedArgumentListExpression)methexp.getArguments();
					for (Iterator<MapEntryExpression> it = args.getMapEntryExpressions().iterator(); it.hasNext(); ) {
						MapEntryExpression mee = it.next();
						if (((String)((ConstantExpression)mee.getKeyExpression()).getValue()).equals("nullable")) {
							boolean b = ((Boolean)((ConstantExpression)mee.getValueExpression()).getValue()).booleanValue();
							NamedArgumentListExpression namedarg = new NamedArgumentListExpression();
							namedarg.addMapEntryExpression(new ConstantExpression("nullable"), new ConstantExpression(b));
							MethodCallExpression constExpr = new MethodCallExpression(
								VariableExpression.THIS_EXPRESSION,
								new ConstantExpression(fieldName),
								namedarg
								);
							block.addStatement(new ExpressionStatement(constExpr));
						}
					}
				}
			}
		}
	}

}

