package i18nfields

class I18nFieldsHelper {
	static void setLocale(loc) {
		org.springframework.context.i18n.LocaleContextHolder.setLocale(loc)
	}
	static Locale getLocale() {
		return org.springframework.context.i18n.LocaleContextHolder.getLocale()
	}
}
