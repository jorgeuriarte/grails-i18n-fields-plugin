import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.commons.metaclass.*

class I18nFieldsGrailsPlugin {
    // the plugin version
    def version = "0.1"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.2-M2 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def author = "Jorge Uriarte"
    def authorEmail = "jorge.uriarte@omelas.net"
    def title = "i18n Fields"
    def description = '''\\
This plugin provide an easy way of declarativily localize database fields of your content tables.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/i18n-fields"

    def getField = { fieldName, langs ->
		delegate."${fieldName}_${i18nfields.I18nFieldsHelper.getLocale().language}"
    }
    
    static Closure getI18nFieldsLocaleClosure = { ->
    	return org.springframework.context.i18n.LocaleContextHolder.getLocale()
    }
    
    static Closure setI18nFieldsLocaleClosure = { locale ->
    	org.springframework.context.i18n.LocaleContextHolder.setLocale(locale)
    }
    
    def doWithDynamicMethods = { ctx ->
        // TODO: getLang()
        // TODO: getI18nFieldValue(field)
        // TODO: setI18nFieldValue(field, value)
    	application.domainClasses.each {domainClass ->
    		MetaClassRegistry registry = GroovySystem.metaClassRegistry
    		def i18n_fields = GrailsClassUtils.getStaticPropertyValue(domainClass.clazz, "i18n_fields" )
    		def i18n_langs = GrailsClassUtils.getStaticPropertyValue(domainClass.clazz, "i18n_langs" )
    		if (i18n_fields && i18n_langs) {
    			i18n_fields.each() { f ->
    				def getter = GrailsClassUtils.getGetterName(f)
    				println "Adding ${getter}"
    				domainClass.metaClass."${getter}" = getField.curry(f, i18n_langs)
    			}
//    			domainClass.metaClass.getI18nFieldsLocale = getI18nFieldsLocaleClosure
//    			domainClass.metaClass.setI18nFieldsLocale = setI18nFieldsLocaleClosure
    		}
    	}
    }

}
