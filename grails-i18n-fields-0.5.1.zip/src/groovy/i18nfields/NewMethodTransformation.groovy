package i18nfields;

import org.codehaus.groovy.transform.ASTTransformation
import org.codehaus.groovy.transform.GroovyASTTransformation

import org.codehaus.groovy.control.CompilePhase
import org.codehaus.groovy.transform.*
import org.codehaus.groovy.ast.*
import org.codehaus.groovy.control.SourceUnit
import org.codehaus.groovy.ast.builder.AstBuilder

@GroovyASTTransformation(phase = CompilePhase.CANONICALIZATION)
public class NewMethodTransformation implements ASTTransformation {

    def _i18n_currentLocale

    public void visit(ASTNode[] astNodes, SourceUnit sourceUnit) {
        println "Visiting..."
        for (ASTNode astNode : astNodes) {
            if (astNode instanceof ClassNode) {
                ClassNode classNode = (ClassNode) astNode;
                def getterName = "getPepito"
                def newast = new AstBuilder().buildFromString(CompilePhase.INSTRUCTION_SELECTION, false, """
                    def soyUnNuevoMetodo() {
                        println "SOY NUEVOOOO!!!"
                    }
                    def getPepito() {
                        println "${this['_i18n_currentLocale']}"
                        return this."${getterName}_${org.springframework.context.i18n.LocaleContextHolder.getLocale()}"
                    }
                """)
                println "Defined..."
                newast[1].methods.each { method ->
                    if (method.name in ['getPepito', 'soyUnNuevoMetodo']) {
                        classNode.addMethod(method)
                        println "Added: ${method}"
                    }
                }
            }
        }
    }

}

