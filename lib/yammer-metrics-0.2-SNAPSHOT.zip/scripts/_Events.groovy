import com.yammer.metrics.reporting.ConsoleReporter

eventTestSuiteEnd = { String type ->
	(new ConsoleReporter(System.out)).run()
}
