package i18nfields

import i18nfields.I18nFieldsHelper;
import i18nfields.tests.TestDomain;

class I18nTestService {

    static transactional = true

    def serviceInDefaultLocale() {
        TestDomain td = TestDomain.get(5)
        td.name
    }
    
    def serviceInOwnLocale() {
        TestDomain td = TestDomain.get(5)
        def ret
        withLocale(new Locale("pt", "PT")) {
            ret = td.name
        }
        return ret
    }
}
