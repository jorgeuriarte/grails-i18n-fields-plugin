package i18nfields

import org.codehaus.groovy.grails.commons.ApplicationHolder
import org.springframework.context.i18n.LocaleContextHolder

class I18nFieldsHelper {
	def literalService

	static transients_model = ["fieldname"]

	static setLocale(Locale locale) {
		LocaleContextHolder.setLocale(locale)
	}

	static getLocale() {
		return LocaleContextHolder.getLocale()
	}

	static withLocale = { Locale newLocale, Closure closure ->
		def previousLocale = i18nfields.I18nFieldsHelper.getLocale()
		i18nfields.I18nFieldsHelper.setLocale(newLocale)
		def result = closure.call()
		i18nfields.I18nFieldsHelper.setLocale(previousLocale)
		return result
	}

	def literalsForField = [:]

	def findFieldFor(field, locale, object) {
		if (!isLocaleLoaded(locale, object)) {
			loadFieldsLocally(locale, object)
		}
		return locallyStoredField(field, locale, object)
	}

	def isLocaleLoaded(locale, object) {
		return object?."${I18nFields.TEMPSTRINGS}"?."${locale.toString()}" != null
	}

	def locallyStoredField(field, locale, object) {
		return fieldInAcceptedLocale(field, locale, object)
	}

	def fieldInAcceptedLocale(field, locale, object) {
		def strings = object?."${I18nFields.TEMPSTRINGS}"
		def locales = []
		if (locale instanceof Locale)
			locales = [locale.toString(), locale.language]
		else
			locales = [locale.toString()]
		for (loc in locales) {
			if (strings[loc]) {
				return strings[loc][field]
			}
		}
	}

	def loadFieldsLocally(locale, object) {
		if (object?.id) {
			def c = Literal.createCriteria()
			c.list {
				eq("myclass", object.class.name)
				eq("myobject", object?.id)
				eq("locale", locale.toString())
			}.each { field ->
				loadFieldLocally(field, locale, object)
			}
		}
	}

	def acceptedLocale(locale, object) {
		def locales = object."${I18nFields.LOCALES}"
		if (locales.containsKey(locale.language)
			&& !locales[locale.language].contains(locale.country)) {
			return new Locale(locale.language)
		} else {
			return locale
		}
	}

	def loadFieldLocally(field, locale, object) {
		def raiz = object?."${I18nFields.TEMPSTRINGS}"
		if (!raiz?."${locale}")
			raiz[locale.toString()] = [:]
		raiz[locale.toString()][field.field] = field.value
	}

	def setFieldFor(field, locale, object, value) {
		def raiz = object."${I18nFields.TEMPSTRINGS}"
		if (!raiz?."${locale}")
			raiz[locale] = [:]
		raiz[locale][field] = value
	}

	def updateFieldsFor(object) {
		literalService = ApplicationHolder.application.mainContext.getBean("literalService")
		literalService.updateFieldsFor(object)
	}

	void deleteFieldsFor(object) {
		Literal.executeUpdate("delete Literal lit where lit.myclass=:myclass and lit.myobject=:myobj",
			[myclass:object.class.name, myobj:object.id])
	}

    static def findAllByLiteralLike(theclass, field, locale, thelike, hql = null, params = []) {
        def clos = finderByLiteral.curry(theclass, 'like')
        return clos.call(locale, field, thelike, hql, params)
    }

    static def findAllByLiteralIs(theclass, field, locale, value, hql = null, params = []) {
    	def clos = finderByLiteral.curry(theclass, '=')
    	return clos.call(locale, field, value, hql, params)
    }

    static Closure finderByLiteral = { theclass, operator, locale, field, value, hql, params ->
        def classname = theclass.name
        def alias = classname.replaceAll(/^(.*\.)?([a-zA-Z]*)/, '$2')
        hql = hql?"and ${hql}":""
        hql = "\
		    select ${alias} \
			from ${classname} as ${alias}, i18nfields.Literal as lit \
			where ${alias}.id = lit.myobject \
			${hql} \
			and lit.myclass = '${classname}' \
			and lit.locale = '${locale}' \
			and lit.field = '${field}' \
			and lit.value ${operator} '${value}' \
		"
	return theclass.executeQuery(hql, params)
    }

}

