import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.commons.metaclass.*
import org.codehaus.groovy.grails.commons.*

class I18nFieldsGrailsPlugin {
    // the plugin version
    def version = "0.4"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp",
            "grails-app/domain/i18nfields/tests/TestDomain.groovy"
    ]

    def config = ConfigurationHolder.config

    // TODO Fill in these fields
    def author = "Jorge Uriarte"
    def authorEmail = "jorge.uriarte@omelas.net"
    def title = "i18n Fields"
    def description = '''\\
This plugin provide an easy way of declarativily localize database fields of your content tables.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/i18n-fields"

    def getField = { fieldName ->
        if (!delegate._i18n_currentLocale)
            delegate._i18n_currentLocale = org.springframework.context.i18n.LocaleContextHolder.getLocale()
        def val = delegate."${fieldName}_${_i18n_currentLocale}"
        return val
    }

    def setField = { fieldName, value ->
        if (!delegate._i18n_currentLocale)
            delegate._i18n_currentLocale = org.springframework.context.i18n.LocaleContextHolder.getLocale()
        delegate."${fieldName}_${_i18n_currentLocale}" = value
    }

    def withLocale = { newLocale, Closure clos ->
        def previous = i18nfields.I18nFieldsHelper.getLocale()
        i18nfields.I18nFieldsHelper.setLocale(newLocale)
        clos.run()
        i18nfields.I18nFieldsHelper.setLocale(previous)
    }


    def doWithDynamicMethods = { ctx ->
        MetaClassRegistry registry = GroovySystem.metaClassRegistry
        application.domainClasses.each {domainClass ->
            def i18n_langs = config.i18nFields.i18n_langs
            if (domainClass.clazz.isAnnotationPresent(i18nfields.I18nFields.class)) {
                println "Internationalizing fields of ${domainClass}"
                def i18n_fields = GrailsClassUtils.getStaticPropertyValue(domainClass.clazz, "i18n_fields" )
                if (i18n_fields) {
                    i18n_fields.each() { f ->
                        def getter = GrailsClassUtils.getGetterName(f)
                        def setter = GrailsClassUtils.getSetterName(f)
                        domainClass.metaClass."${getter}" = getField.curry(f)
                        domainClass.metaClass."${setter}" = setField.curry(f)
                        println " - Added ${getter} and ${setter}"
                    }
                }
            }
        }
        ['controller', 'service', 'tagLib', 'codec', 'bootstrap', 'urlMapping'].each {
            application."${it}Classes".each { theClass ->
                theClass.metaClass.withLocale = withLocale
            }
        }
    }

}

